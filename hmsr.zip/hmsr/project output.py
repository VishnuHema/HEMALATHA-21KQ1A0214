Python 3.11.9 (tags/v3.11.9:de54cf5, Apr  2 2024, 10:12:12) [MSC v.1938 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\POOJITHA\AppData\Local\Programs\Python\Python311\proj\data3.py
20
enter student name:jaya
enter roll number:1
enter marks:7 2 8
enter student name:maya
enter roll number:2
enter marks:5 2 7
enter student name:raju
enter roll number:3
enter marks:7 3 9
enter student name:gaya
enter roll number:4
enter marks:7 3 3
enter student name:vina
enter roll number:5
enter marks:6 3 3
enter student name:ravi
enter roll number:6
enter marks:7 3 3
enter student name:navi
enter roll number:7
enter marks:8 8 9
enter student name:fairy
enter roll number:8
enter marks:8 3 8
enter student name:divya
enter roll number:9
enter marks:8 6 9
enter student name:diya
enter roll number:10
enter marks:6 6 8
enter student name:rani
enter roll number:11
enter marks:6 2 7
enter student name:vani
enter roll number:12
enter marks:8 8 7
enter student name:mani
enter roll number:13
enter marks:4 3 2
enter student name:ak
enter roll number:14
enter marks:6 3 5
enter student name:mina
enter roll number:15
enter marks:7 8 9
enter student name:manu
enter roll number:16
enter marks:7 7 8
enter student name:asha
enter roll number:17
enter marks:7 7 3
enter student name:kama
enter roll number:18
enter marks:7 3 7
enter student name:merit
enter roll number:19
enter marks:4 8 7
enter student name:naga
enter roll number:20
enter marks:6 6 8
     name  rollnumber      marks  total
0    jaya           1  [7, 2, 8]     17
1    maya           2  [5, 2, 7]     14
2    raju           3  [7, 3, 9]     19
3    gaya           4  [7, 3, 3]     13
4    vina           5  [6, 3, 3]     12
5    ravi           6  [7, 3, 3]     13
6    navi           7  [8, 8, 9]     25
7   fairy           8  [8, 3, 8]     19
8   divya           9  [8, 6, 9]     23
9    diya          10  [6, 6, 8]     20
10   rani          11  [6, 2, 7]     15
11   vani          12  [8, 8, 7]     23
12   mani          13  [4, 3, 2]      9
13     ak          14  [6, 3, 5]     14
14   mina          15  [7, 8, 9]     24
15   manu          16  [7, 7, 8]     22
16   asha          17  [7, 7, 3]     17
17   kama          18  [7, 3, 7]     17
18  merit          19  [4, 8, 7]     19
19   naga          20  [6, 6, 8]     20
max total=: 25
min total=: 9
sort total=: [9, 12, 13, 13, 14, 14, 15, 17, 17, 17, 19, 19, 19, 20, 20, 22, 23, 23, 24, 25]
{9, 12, 13, 14, 15, 17, 19, 20, 22, 23, 24, 25}
maximum score of student1: 8
minimum score of student1: 2
total score of student1: 17
average score of student1: 5.666666666666667
sort of all marks 1: [2, 7, 8]
score of each subject without duplicates: {8, 2, 7}
maximum score of student2: 7
minimum score of student2: 2
total score of student2: 14
average score of student2: 4.666666666666667
sort of all marks 2: [2, 5, 7]
score of each subject without duplicates: {2, 5, 7}
maximum score of student3: 9
minimum score of student3: 3
total score of student3: 19
average score of student3: 6.333333333333333
sort of all marks 3: [3, 7, 9]
score of each subject without duplicates: {9, 3, 7}
maximum score of student4: 7
minimum score of student4: 3
total score of student4: 13
average score of student4: 4.333333333333333
sort of all marks 4: [3, 3, 7]
score of each subject without duplicates: {3, 7}
maximum score of student5: 6
minimum score of student5: 3
total score of student5: 12
average score of student5: 4.0
sort of all marks 5: [3, 3, 6]
score of each subject without duplicates: {3, 6}
maximum score of student6: 7
minimum score of student6: 3
total score of student6: 13
average score of student6: 4.333333333333333
sort of all marks 6: [3, 3, 7]
score of each subject without duplicates: {3, 7}
maximum score of student7: 9
minimum score of student7: 8
total score of student7: 25
average score of student7: 8.333333333333334
sort of all marks 7: [8, 8, 9]
score of each subject without duplicates: {8, 9}
maximum score of student8: 8
minimum score of student8: 3
total score of student8: 19
average score of student8: 6.333333333333333
sort of all marks 8: [3, 8, 8]
score of each subject without duplicates: {8, 3}
maximum score of student9: 9
minimum score of student9: 6
total score of student9: 23
average score of student9: 7.666666666666667
sort of all marks 9: [6, 8, 9]
score of each subject without duplicates: {8, 9, 6}
maximum score of student10: 8
minimum score of student10: 6
total score of student10: 20
average score of student10: 6.666666666666667
sort of all marks 10: [6, 6, 8]
score of each subject without duplicates: {8, 6}
maximum score of student11: 7
minimum score of student11: 2
total score of student11: 15
average score of student11: 5.0
sort of all marks 11: [2, 6, 7]
score of each subject without duplicates: {2, 6, 7}
maximum score of student12: 8
minimum score of student12: 7
total score of student12: 23
average score of student12: 7.666666666666667
sort of all marks 12: [7, 8, 8]
score of each subject without duplicates: {8, 7}
maximum score of student13: 4
minimum score of student13: 2
total score of student13: 9
average score of student13: 3.0
sort of all marks 13: [2, 3, 4]
score of each subject without duplicates: {2, 3, 4}
maximum score of student14: 6
minimum score of student14: 3
total score of student14: 14
average score of student14: 4.666666666666667
sort of all marks 14: [3, 5, 6]
score of each subject without duplicates: {3, 5, 6}
maximum score of student15: 9
minimum score of student15: 7
total score of student15: 24
average score of student15: 8.0
sort of all marks 15: [7, 8, 9]
score of each subject without duplicates: {8, 9, 7}
maximum score of student16: 8
minimum score of student16: 7
total score of student16: 22
average score of student16: 7.333333333333333
sort of all marks 16: [7, 7, 8]
score of each subject without duplicates: {8, 7}
maximum score of student17: 7
minimum score of student17: 3
total score of student17: 17
average score of student17: 5.666666666666667
sort of all marks 17: [3, 7, 7]
score of each subject without duplicates: {3, 7}
maximum score of student18: 7
minimum score of student18: 3
total score of student18: 17
average score of student18: 5.666666666666667
sort of all marks 18: [3, 7, 7]
score of each subject without duplicates: {3, 7}
maximum score of student19: 8
minimum score of student19: 4
total score of student19: 19
average score of student19: 6.333333333333333
sort of all marks 19: [4, 7, 8]
score of each subject without duplicates: {8, 4, 7}
maximum score of student20: 8
minimum score of student20: 6
total score of student20: 20
average score of student20: 6.666666666666667
sort of all marks 20: [6, 6, 8]
score of each subject without duplicates: {8, 6}
maximum marks in subject 1: 8
maximum marks in subject 2: 8
maximum marks in subject 3: 9
